# proyecto_Python

MyData

![imagen](/img/MyData.jpg)

El mismo es un programa que busca orientar y analizar los productos más comercializados en la industria. Tambíen permite realizar reporte por visitador / farmacia.

**Pre-requisitos📋**\
Solo necesitamos abrir el navegador y colocar la siguiente ruta : http://127.0.0.1:5000/ \
En Visual Studio Code podemos ver las librerias instaladas para poder correr el programa.




__Comenzando 💻__



![imagen](/img/Navegador.jpg)

En el navegador vamos a poder realizar un vistazo de lo aprendido, en la solapa Registro puede ingresar el nombre del laboratorio, el nombre de la persona
y la cantida de unidades vendidas.

![imagen](/img/Registro.jpg)

**Ejecucón del programa🛠️**

Lo que podremos obtener es la cantidad de ventas por visitador por Laboratorio, para ello tienen que realizar click en el link
que se encuentra en la tabla.

![imagen](/img/Tabla.jpg)


__Gráficos 💻__


Realizando click en el link, vamos a llegar al gráfico con los valores por laboratorio por vendedor.

**Visual Studio Code**\
**Github**\
**Versionado📌**\
\_\_Versión 1.0

Autores ✒
Proyecto realizado por : ● Salinas Javier DNI : 27794377

Licencia📄
Este proyecto está bajo la Licencia (27.794.377)




